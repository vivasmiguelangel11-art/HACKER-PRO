package com.hackerpro.training

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private val Neon = Color(0xFF39FF14)
private val Bg = Color(0xFF050805)
private val Panel = Color(0xFF101710)
private val Muted = Color(0xFF9EB39B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HackerProApp() }
    }
}

@Composable
fun HackerProApp() {
    var tab by remember { mutableStateOf(0) }
    var sensitivity by remember { mutableFloatStateOf(72f) }
    var general by remember { mutableFloatStateOf(90f) }
    var redDot by remember { mutableFloatStateOf(82f) }
    var fps by remember { mutableStateOf("Alto") }
    var session by remember { mutableIntStateOf(0) }
    var showHelp by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Neon, background = Bg, surface = Panel,
        onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("HACKER PRO", color = Neon, fontSize = 27.sp, fontWeight = FontWeight.Black)
                    Text("FREE FIRE • CENTRO DE ENTRENAMIENTO", color = Muted, fontSize = 10.sp)
                }
                Text("V1.0", color = Neon, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TabChip("INICIO", tab == 0) { tab = 0 }
                TabChip("ENTRENAR", tab == 1) { tab = 1 }
                TabChip("AJUSTES", tab == 2) { tab = 2 }
            }
            Spacer(Modifier.height(14.dp))
            when (tab) {
                0 -> {
                    NeonCard {
                        Text("PANEL DE CONTROL", color = Neon, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("Entrena tu precisión y reflejos sin modificar Free Fire ni intervenir en partidas reales.",
                            color = Muted, fontSize = 13.sp)
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatBox("SESIONES", session.toString(), Modifier.weight(1f))
                            StatBox("MODO", "PRÁCTICA", Modifier.weight(1f))
                            StatBox("ESTADO", "LISTO", Modifier.weight(1f))
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    FeatureRow("🎯", "HEADSHOT TRAINER", "Practica apuntar a objetivos en el simulador")
                    FeatureRow("🧲", "AIM TRACKING", "Sigue objetivos móviles y mejora el control")
                    FeatureRow("📡", "RADAR SIMULADO", "Detecta objetivos de entrenamiento")
                    FeatureRow("⚡", "FPS Y RENDIMIENTO", "Consejos de configuración para Android")
                }
                1 -> {
                    NeonCard {
                        Text("CAMPO DE PRÁCTICA", color = Neon, fontWeight = FontWeight.Bold)
                        Text("Toca los objetivos verdes para practicar tu reacción.", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(10.dp))
                        PracticeBoard(onHit = { session++ })
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { session++ }, colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Color.Black),
                            modifier = Modifier.fillMaxWidth()) { Text("INICIAR RONDA DE PRÁCTICA", fontWeight = FontWeight.Bold) }
                    }
                    Spacer(Modifier.height(12.dp))
                    NeonCard {
                        Text("ENTRENAMIENTO DE REFLEJOS", color = Neon, fontWeight = FontWeight.Bold)
                        Text("Haz rondas cortas y busca mejorar tu tiempo de reacción.", color = Muted, fontSize = 12.sp)
                        Text("Rondas completadas: $session", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    }
                }
                else -> {
                    NeonCard {
                        Text("SENSIBILIDAD PERSONALIZADA", color = Neon, fontWeight = FontWeight.Bold)
                        SliderSetting("General", general) { general = it }
                        SliderSetting("Punto rojo", redDot) { redDot = it }
                        SliderSetting("Control de cámara", sensitivity) { sensitivity = it }
                        Text("Estos valores son recomendaciones de práctica; no se aplican automáticamente al juego.",
                            color = Muted, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                    NeonCard {
                        Text("RENDIMIENTO ANDROID", color = Neon, fontWeight = FontWeight.Bold)
                        Text("Perfil gráfico", color = Muted)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Suave", "Medio", "Alto").forEach { option ->
                                TabChip(option.uppercase(), fps == option) { fps = option }
                            }
                        }
                        Text("Cierra apps en segundo plano y evita jugar mientras el teléfono se sobrecalienta.",
                            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("HERRAMIENTA DE ENTRENAMIENTO INDEPENDIENTE • NO SE CONECTA NI INYECTA CÓDIGO EN FREE FIRE",
                color = Muted, fontSize = 9.sp)
        }
    }
}

@Composable
fun TabChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(Modifier.border(1.dp, if (selected) Neon else Color(0xFF344334), RoundedCornerShape(10.dp))
        .background(if (selected) Neon.copy(alpha = .13f) else Panel, RoundedCornerShape(10.dp))
        .clickable { onClick() }.padding(horizontal = 12.dp, vertical = 10.dp)) {
        Text(label, color = if (selected) Neon else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun NeonCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().border(1.dp, Neon.copy(alpha = .7f), RoundedCornerShape(16.dp))
        .background(Panel, RoundedCornerShape(16.dp)).padding(14.dp), content = content)
}

@Composable
fun StatBox(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Color(0xFF071007), RoundedCornerShape(10.dp)).padding(9.dp)) {
        Text(label, color = Muted, fontSize = 9.sp)
        Text(value, color = Neon, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
fun FeatureRow(icon: String, title: String, desc: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(12.dp)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 22.sp)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = Neon, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(desc, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun SliderSetting(label: String, value: Float, onChange: (Float) -> Unit) {
    Text("$label: ${value.toInt()}", color = Color.White, fontSize = 12.sp)
    Slider(value = value, onValueChange = onChange, valueRange = 0f..100f,
        colors = SliderDefaults.colors(thumbColor = Neon, activeTrackColor = Neon))
}

@Composable
fun PracticeBoard(onHit: () -> Unit) {
    var target by remember { mutableStateOf(Offset(.5f, .5f)) }
    Box(Modifier.fillMaxWidth().height(230.dp).background(Color(0xFF071207), RoundedCornerShape(12.dp))
        .clickable {
            target = Offset(Random.nextFloat() * .8f + .1f, Random.nextFloat() * .8f + .1f)
            onHit()
        }) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width * target.x
            val cy = size.height * target.y
            drawCircle(Neon.copy(alpha = .18f), radius = 42f, center = Offset(cx, cy))
            drawCircle(Neon, radius = 22f, center = Offset(cx, cy), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f))
            drawCircle(Neon, radius = 5f, center = Offset(cx, cy))
            drawLine(Neon.copy(alpha = .3f), Offset(size.width/2, 0f), Offset(size.width/2, size.height), 1f)
            drawLine(Neon.copy(alpha = .3f), Offset(0f, size.height/2), Offset(size.width, size.height/2), 1f)
        }
        Text("TOCA PARA DISPARAR", color = Muted, fontSize = 9.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(8.dp))
    }
}
