# HACKER PRO — Android

Aplicación Android independiente de entrenamiento visual con tema negro y verde neón.

## Incluye
- Pantalla de inicio HACKER PRO.
- Campo de práctica táctil con objetivos móviles.
- Contador de rondas.
- Ajustes de sensibilidad de práctica.
- Consejos de rendimiento y perfil gráfico ilustrativo.

## Abrir y compilar
1. Instala Android Studio.
2. Abre la carpeta `HACKER_PRO_Android`.
3. Espera la sincronización de Gradle.
4. Ejecuta en un dispositivo Android o emulador.

Para generar un APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Esta app no se conecta a Free Fire, no modifica sus archivos, no inyecta código y no automatiza apuntado en partidas reales. Los controles son simulaciones/entrenamiento independiente.
